import { Injectable } from '@nestjs/common';

export function CustomInjectable() {
  return Injectable();
}
