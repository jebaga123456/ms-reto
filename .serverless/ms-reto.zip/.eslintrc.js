module.exports = {
  // ... your existing config
  rules: {
    '@typescript-eslint/no-redundant-type-constituents': 'off',
    '@typescript-eslint/no-unsafe-assignment': 'off',
    'prettier/prettier': 'off'
  }
}